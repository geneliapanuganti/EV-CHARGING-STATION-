EV CHARGING STATION PLANNER — INTERACTIVE PROTOTYPE

Open index.html in a browser.

Prototype flow:
1. Find Best Station
2. Click Go to Exact Spot
3. Vehicle moves quickly to the selected station
4. Vehicle stops and remains at the exact destination
5. Charge becomes enabled only after arrival
6. Charging raises battery to 100%
7. Reset returns to the original position

This is a front-end prototype for demonstration. It does not require Flask or an internet connection.
